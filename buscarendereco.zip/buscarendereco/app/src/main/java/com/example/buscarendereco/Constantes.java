package com.example.buscarendereco;

public class Constantes {
    public static String URL = "https://api.invertexto.com/";
    public static String TOKEN = "18430|Nz4UwivpyRh7NZSeZb076O9ZdsfpchNX";
}
