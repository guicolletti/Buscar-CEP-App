package com.example.buscarendereco.model;
public class Logradouro {
    private String cep;
    private String state;
    private String city;
    private String neighborhood;
    private String street;
    private String complement;
    private String ibge;

    @Override
    public String toString() {
        return "Estado: " + state + "\n" +
                "Cidade: " + city + "\n" +
                "Bairro: " + neighborhood + "\n" +
                "Rua: " + street + "\n" +
                "Complemento: " + complement;
    }
}