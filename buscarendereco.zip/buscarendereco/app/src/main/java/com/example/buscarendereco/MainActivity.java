package com.example.buscarendereco;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.buscarendereco.model.Logradouro;
import com.example.buscarendereco.service.InvertextoApi;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class MainActivity extends AppCompatActivity {

    TextView tvInformacoes;
    EditText etCep;
    Button btnConsultar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        // Referências aos elementos do layout
        tvInformacoes = findViewById(R.id.tvInformacoes);
        etCep = findViewById(R.id.etCep);
        btnConsultar = findViewById(R.id.btnConsultar);

        // Aplicação de insets para janela
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // Configuração do botão de consulta
        btnConsultar.setOnClickListener(v -> {
            String numeroCep = etCep.getText().toString().trim();

            if (!numeroCep.isEmpty()) {
                consultar(numeroCep);  // Chama a função consultar com o CEP inserido
            } else {
                Toast.makeText(MainActivity.this, "Por favor, insira um CEP válido", Toast.LENGTH_SHORT).show();
            }
        });
    }

    // Função para realizar a consulta na API
    private void consultar(String numeroCep) {

        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(Constantes.URL)
                .addConverterFactory(GsonConverterFactory.create())
                .build();

        InvertextoApi invertextoApi = retrofit.create(InvertextoApi.class);

        Call<Logradouro> call = invertextoApi.getEndereco(numeroCep, Constantes.TOKEN);

        call.enqueue(new Callback<Logradouro>() {
            @Override
            public void onResponse(Call<Logradouro> call, Response<Logradouro> response) {

                if (response.isSuccessful()) {
                    Logradouro logradouro = response.body();
                    if (logradouro != null) {
                        tvInformacoes.setText(logradouro.toString());  // Exibe o resultado na TextView
                    } else {
                        tvInformacoes.setText("CEP não encontrado.");
                    }
                } else {
                    Toast.makeText(MainActivity.this, "Erro ao converter resposta da API", Toast.LENGTH_LONG).show();
                }
            }

            @Override
            public void onFailure(Call<Logradouro> call, Throwable throwable) {
                Toast.makeText(MainActivity.this, "Erro ao realizar consulta na API", Toast.LENGTH_LONG).show();
            }
        });
    }
}